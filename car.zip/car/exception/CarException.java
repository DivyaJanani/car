package com.cg.car.exception;


	public class CarException extends Exception{

		public CarException(String excep) {
			super();
			System.out.println(excep);
		}
				
		
	}


